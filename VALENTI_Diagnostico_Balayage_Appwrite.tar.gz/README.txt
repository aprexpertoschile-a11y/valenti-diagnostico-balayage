VALENTI Diagnóstico Balayage — Appwrite
==========================================
Configuración incluida:
- Endpoint: https://fra.cloud.appwrite.io/v1
- Project ID: 6ab72cfd003e11063378
- Database ID: 6ab72f630003229be618
- Table ID: 6ab72f63003229be618

La versión no usa fotos. El cliente completa el formulario y crea una fila
en Appwrite. No contiene claves API secretas.

IMPORTANTE:
Para usarla desde un dominio real, agrega ese dominio en Appwrite:
Ajustes del proyecto -> Plataformas -> Web.
No compartas ninguna API key en el navegador.

Columnas esperadas:
nombre
telefono
cabello_actual
procesos_quimicos
ultimo_proceso
estado_cabello
foto_id
